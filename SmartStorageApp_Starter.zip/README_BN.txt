SMART STORAGE & APP MANAGER — STARTER PROJECT
=============================================

এই ZIP-এ Android Studio project-এর প্রাথমিক source code দেওয়া আছে।
এটি একটি starter version: App Manager, app sorting, storage size estimate,
usage access shortcut এবং Android system uninstall confirmation আছে।

কীভাবে চালাবেন:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP ফাইল Extract করুন।
3. Android Studio > Open > Extract করা SmartStorageApp folder নির্বাচন করুন।
4. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
5. ফোনে Developer options থেকে USB debugging চালু করে USB দিয়ে যুক্ত করুন,
   অথবা Android Studio-র emulator চালু করুন।
6. Run (সবুজ ▶) চাপুন।
7. Usage Access বাটনে চাপ দিয়ে Smart Storage-কে Usage Access দিন।
8. অ্যাপে ফিরে Scan Apps চাপুন।

গুরুত্বপূর্ণ:
- এটি এখনো Play Store release-ready নয়।
- Android Studio/Gradle প্রথমবার internet থেকে dependencies নামাবে।
- QUERY_ALL_PACKAGES Google Play-তে নীতিমালা-সাপেক্ষ; প্রকাশের আগে review করতে হবে।
- Storage size কিছু ডিভাইসে unavailable দেখাতে পারে।
- Uninstall করার আগে Android confirmation দেখাবে।
- File scanning, duplicate cleanup এবং full dashboard পরবর্তী উন্নয়ন ধাপ।
- Android Studio build error এলে error message/screenshot পাঠালে সেটি ঠিক করতে সাহায্য করা যাবে।
