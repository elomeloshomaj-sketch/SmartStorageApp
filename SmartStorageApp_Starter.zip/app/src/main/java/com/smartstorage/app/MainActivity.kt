package com.smartstorage.app

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

data class AppItem(
    val packageName: String,
    val label: String,
    val icon: android.graphics.drawable.Drawable,
    val sizeBytes: Long?,
    val lastUsed: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    SmartStorageScreen()
                }
            }
        }
    }
}

@Composable
fun SmartStorageScreen() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf("Size") }
    var message by remember { mutableStateOf("Tap Scan Apps to begin.") }
    var confirmApp by remember { mutableStateOf<AppItem?>(null) }

    suspend fun scan() {
        loading = true
        try {
            apps = loadApps(context)
            apps = sortApps(apps, sort)
            message = "Found ${apps.size} user-installed apps."
        } catch (e: Exception) {
            message = "Could not scan apps: ${e.localizedMessage ?: "unknown error"}"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { scan() }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Smart Storage", style = MaterialTheme.typography.headlineMedium)
        Text("App Manager • Starter version", style = MaterialTheme.typography.bodyMedium)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Usage access", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (hasUsageAccess(context)) "Usage access is enabled"
                    else "Enable Usage Access to see app last-used times."
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }) { Text("Usage Access") }
                    OutlinedButton(onClick = {
                        // Reload after returning from Settings.
                        kotlinx.coroutines.MainScope().launch { scan() }
                    }) { Text("Scan Apps") }
                }
            }
        }

        Text(message, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = sort == "Size", onClick = {
                sort = "Size"; apps = sortApps(apps, sort)
            }, label = { Text("Largest") })
            FilterChip(selected = sort == "Least used", onClick = {
                sort = "Least used"; apps = sortApps(apps, sort)
            }, label = { Text("Least used") })
            FilterChip(selected = sort == "Name", onClick = {
                sort = "Name"; apps = sortApps(apps, sort)
            }, label = { Text("Name") })
        }

        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(apps, key = { it.packageName }) { app ->
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            bitmap = remember(app.icon) {
                                app.icon.toBitmap(96, 96).asImageBitmap()
                            },
                            contentDescription = null,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.label, style = MaterialTheme.typography.titleSmall,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Size: ${formatBytes(app.sizeBytes)}",
                                style = MaterialTheme.typography.bodySmall)
                            Text("Last used: ${formatDate(app.lastUsed)}",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { confirmApp = app }) { Text("Uninstall") }
                    }
                }
            }
        }
    }

    confirmApp?.let { app ->
        AlertDialog(
            onDismissRequest = { confirmApp = null },
            title = { Text("Uninstall ${app.label}?") },
            text = { Text("Android will show its own confirmation screen. You can cancel there.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmApp = null
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                        )
                    } catch (_: Exception) {
                        message = "Could not open system uninstaller."
                    }
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = { confirmApp = null }) { Text("Cancel") }
            }
        )
    }
}

private suspend fun loadApps(context: Context): List<AppItem> =
    withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val now = System.currentTimeMillis()
        val usageManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val usage = try {
            usageManager.queryAndAggregateUsageStats(now - 365L * 24 * 60 * 60 * 1000, now)
        } catch (_: SecurityException) {
            emptyMap()
        }

        val storageManager = context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val installed = try {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        } catch (_: NoSuchMethodError) {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }

        installed.asSequence()
            .filter {
                (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            }
            .map { app ->
                val bytes = try {
                    val stats = storageManager.queryStatsForPackage(
                        app.storageUuid ?: StorageManager.UUID_DEFAULT,
                        app.packageName,
                        Process.myUserHandle()
                    )
                    stats.appBytes + stats.dataBytes + stats.cacheBytes
                } catch (_: Exception) {
                    null
                }
                AppItem(
                    packageName = app.packageName,
                    label = pm.getApplicationLabel(app).toString(),
                    icon = pm.getApplicationIcon(app),
                    sizeBytes = bytes,
                    lastUsed = usage[app.packageName]?.lastTimeUsed ?: 0L
                )
            }.toList()
    }

private fun hasUsageAccess(context: Context): Boolean {
    val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    return ops.checkOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS,
        Process.myUid(),
        context.packageName
    ) == AppOpsManager.MODE_ALLOWED
}

private fun sortApps(apps: List<AppItem>, mode: String): List<AppItem> = when (mode) {
    "Size" -> apps.sortedByDescending { it.sizeBytes ?: -1L }
    "Least used" -> apps.sortedWith(
        compareBy<AppItem> { if (it.lastUsed == 0L) 1 else 0 }.thenBy { it.lastUsed }
    )
    else -> apps.sortedBy { it.label.lowercase() }
}

private fun formatBytes(bytes: Long?): String {
    if (bytes == null) return "Unavailable"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) "%.2f GB".format(mb / 1024.0) else "%.1f MB".format(mb)
}

private fun formatDate(time: Long): String =
    if (time <= 0L) "Usage data unavailable"
    else DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(time))
